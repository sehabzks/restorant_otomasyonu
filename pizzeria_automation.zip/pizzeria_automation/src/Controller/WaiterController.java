
package Controller;


import DAO.WaiterDAO;
import Entity.waiter;
import java.io.IOException;
import java.util.List;


public class WaiterController {
    private waiter entity;
    private List<waiter> list;
    private WaiterDAO dao;
    
    
    public void create(int Id) throws IOException{
        waiter newWaiter = this.getEntity();
        newWaiter.setId(Id);
        
        
        
    }

    public waiter getEntity() {
        if(this.entity == null){
            entity = new waiter();
        }
        return entity;
    }

    public void setEntity(waiter entity) {
        this.entity = entity;
    }

    public List<waiter> getList() {
        return list;
    }

    public void setList(List<waiter> list) {
        this.list = list;
    }

    public WaiterDAO getDao() {
        if(this.dao == null){
            dao = new WaiterDAO();
        }
        return dao;
    }

    public void setDao(WaiterDAO dao) {
        this.dao = dao;
    }
    
}
