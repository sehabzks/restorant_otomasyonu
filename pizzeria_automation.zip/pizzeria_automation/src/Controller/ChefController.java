
package Controller;

import DAO.ChefDAO;
import Entity.chef;
import java.io.IOException;
import java.util.List;

public class ChefController {
     private chef entity;
    private List<chef> list;
    private ChefDAO dao;
    
    
    public void create(int Id) throws IOException{
        chef newChef = this.getEntity();
        newChef.setId(Id);
        
        
        
    }
    public chef getEntity() {
        if(this.entity == null){
            entity = new chef();
        }
        return entity;
    }
    public void setEntity(chef entity) {
        this.entity = entity;
    }

    public List<chef> getList() {
        return list;
    }

    public void setList(List<chef> list) {
        this.list = list;
    }

    public ChefDAO getDao() {
        if(this.dao == null){
            dao = new ChefDAO();
        }
        return dao;
    }

    public void setDao(ChefDAO dao) {
        this.dao = dao;
    }

    
}
