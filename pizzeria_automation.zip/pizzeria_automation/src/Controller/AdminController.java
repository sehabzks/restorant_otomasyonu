package Controller;

import DAO.AdminDAO;
import Entity.Admin;
import Entity.Food;
import Entity.Personel;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AdminController {

    private Admin entity;
    private List<Admin> list;
    private AdminDAO dao;

    public void create(int Id) throws IOException {
        Admin newAdmin = this.getEntity();
        newAdmin.setId(Id);

    }

    public boolean Kontrol(String kullaniciAdi, String sifre) throws IOException {
        AdminDAO adm = new AdminDAO();
        Admin admin = new Admin(kullaniciAdi, sifre);
        if (adm.Kontrol(admin)) {
            return true;
        } else {
            return false;
        }

    }

    public ArrayList<Personel> getPersonelList() {
        AdminDAO adm = new AdminDAO();
        ArrayList<Personel> list = adm.getPersonelList();

        return list;
    }

    public List<Food> getFoodList(){
        AdminDAO adm = new AdminDAO();
        ArrayList<Food> list = adm.getFoodList();
        return list;
    }
    
    public boolean YemekEkle(int id, String name,int price) throws IOException {
        Food food = new Food(id, name, price);
        AdminDAO adm = new AdminDAO();
        adm.YemekEkle(food);
        return true;
    }
    
    public boolean PersonelEkle(int id, String name, int Salary, String type) throws IOException {
        Personel personel = new Personel(id, name, Salary, type);
        AdminDAO adm = new AdminDAO();
        adm.PersonelEkle(personel);
        return true;
    }

    public Admin getEntity() {
        if (this.entity == null) {
            entity = new Admin();
        }
        return entity;
    }

    public void setEntity(Admin entity) {
        this.entity = entity;
    }

    public List<Admin> getList() {
        return list;
    }

    public void setList(List<Admin> list) {
        this.list = list;
    }

    public AdminDAO getDao() {
        if (this.dao == null) {
            dao = new AdminDAO();
        }
        return dao;
    }

    public void setDao(AdminDAO dao) {
        this.dao = dao;
    }

}
