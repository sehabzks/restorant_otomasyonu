package main;
import File.FileOp;
import gui.*;
import java.io.IOException;

public class Pizzeria_automation {
    
    public static void main(String[] args) throws IOException {

       GUI g = new GUI();
        
    }
    
}
