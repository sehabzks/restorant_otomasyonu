package gui;

import Action.TablesAction;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Tables extends JFrame {
    private JButton masa1;
    private JButton masa2;
    private JButton masa3;
    private JButton masa4;
    private JButton masa5;
    private JButton masa6;

    public Tables() throws IOException {
        initJFrame();
    }

    private void initJFrame() throws IOException {
        add(initPanel());
        setTitle("Restoran Otomasyonu");
        setIconImage(ImageIO.read(new File("res/Icon.png")));
        setSize(440, 340);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JPanel initPanel() {
        JPanel masaPanel = new JPanel();
        masaPanel.setLayout(null);

        masaPanel.add(getMasa1());
        masaPanel.add(getMasa2());
        masaPanel.add(getMasa3());
        masaPanel.add(getMasa4());
        masaPanel.add(getMasa5());
        masaPanel.add(getMasa6());

        return masaPanel;
    }

    public JButton getMasa1() {
        if (masa1 == null) {
            this.masa1 = new JButton("masa1");
            masa1.setBounds(30, 30, 100, 100);
            masa1.addActionListener(new TablesAction(this));
        }
        return masa1;
    }

    public void setMasa1(JButton masa1) {
        this.masa1 = masa1;
    }

    public JButton getMasa2() {
        if (masa2 == null) {
            this.masa2 = new JButton("masa2");
            masa2.setBounds(160, 30, 100, 100);
            masa2.addActionListener(new TablesAction(this));
        }
        return masa2;
    }

    public void setMasa2(JButton masa2) {
        this.masa2 = masa2;
    }

    public JButton getMasa3() {
        if (masa3 == null) {
            this.masa3 = new JButton("masa3");
            masa3.setBounds(290, 30, 100, 100);
            masa3.addActionListener(new TablesAction(this));
        }
        return masa3;
    }

    public void setMasa3(JButton masa3) {
        this.masa3 = masa3;
    }

    public JButton getMasa4() {
        if (masa4 == null) {
            this.masa4 = new JButton("masa4");
            masa4.setBounds(30, 160, 100, 100);
            masa4.addActionListener(new TablesAction(this));
        }
        return masa4;
    }

    public void setMasa4(JButton masa4) {
        this.masa4 = masa4;
    }

    public JButton getMasa5() {
        if (masa5 == null) {
            this.masa5 = new JButton("masa5");
            masa5.setBounds(160, 160, 100, 100);
            masa5.addActionListener(new TablesAction(this));
        }
        return masa5;
    }

    public void setMasa5(JButton masa5) {
        this.masa5 = masa5;
    }

    public JButton getMasa6() {
        if (masa6 == null) {
            this.masa6 = new JButton("masa6");
            masa6.setBounds(290, 160, 100, 100);
            masa6.addActionListener(new TablesAction(this));
        }
        return masa6;
    }

    public void setMasa6(JButton masa6) {
        this.masa6 = masa6;
    }
}
