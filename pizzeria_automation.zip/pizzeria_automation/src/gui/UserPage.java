package gui;

import Action.UserOpenPageAction;
import Controller.AdminController;
import Entity.Food;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.table.DefaultTableModel;

public class UserPage extends JFrame {

    private JLabel lb1, lb2;
    private JButton b2, b3;
    private JButton menu1,menu2,menu3,menu4,menu5,menu6,menu7,menu8;
    private JTable adisyon,foodTable;
    private DefaultTableModel foodModel;
    private Object[] foodData = null;
    private JScrollPane addFoodsp;
    AdminController admin;

    public UserPage() throws IOException {
        foodModel = new DefaultTableModel();
        admin = new AdminController();
        
        Object[] colFoodName = new Object[3];
        colFoodName[0] = "ID";
        colFoodName[1] = "Name";
        colFoodName[2] = "Price";
        
        foodModel.setColumnIdentifiers(colFoodName);
        foodData = new Object[4];
        java.util.List<Food> foods = admin.getFoodList();
        for (int i = 0; i < foods.size(); i++) {
            foodData[0] = foods.get(i).getId();
            foodData[1] = foods.get(i).getName();
            foodData[2] = foods.get(i).getPrice();            
            foodModel.addRow(foodData);
        }
        initJFrame();
    }
    
    public void updatefoodModel() {

        foodModel.setRowCount(0);
        java.util.List<Food> foods = admin.getFoodList();
        for (int i = 0; i < foods.size(); i++) {
            foodData[0] = foods.get(i).getId();
            foodData[1] = foods.get(i).getName();
            foodData[2] = foods.get(i).getPrice();            
            foodModel.addRow(foodData);
        }
    }

    private void initJFrame() throws IOException {
        add(initPanel());
        setTitle("Restoran Otomasyonu");
        setIconImage(ImageIO.read(new File("res/Icon.png")));
        setSize(900, 600);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    public JTable getFoodTable() {
        if (foodTable == null) {
            this.foodTable = new JTable();
            foodTable.setBounds(800, 100, 250, 350);
            foodTable.setModel(foodModel);
        }
        return foodTable;
    }

    public void setFoodTable(JTable foodTable) {
        this.foodTable = foodTable;
    }
    
    public JScrollPane getAddFoodsp() {
        if (addFoodsp == null) {
            this.addFoodsp = new JScrollPane(getFoodTable());
            addFoodsp.setBounds(350, 100, 250, 350);
            addFoodsp.setViewportView(getFoodTable());
        }
        return addFoodsp;
    }

    public void setAddFoodsp(JScrollPane addFoodsp) {
        this.addFoodsp = addFoodsp;
    }

    public JButton getMenu1() {
        if(menu1 == null){
            this.menu1 = new JButton("menu 1");
            menu1.setBounds(20,50,80,30);
        }
        return menu1;
    }

    public void setMenu1(JButton menu1) {
        this.menu1 = menu1;
    }

    public JButton getMenu2() {
        if(menu2 == null){
            this.menu2 = new JButton("menu 2");
            menu2.setBounds(20,90,80,30);
        }
        return menu2;
    }

    public void setMenu2(JButton menu2) {
        this.menu2 = menu2;
    }

    public JButton getMenu3() {
        if(menu3 == null){
            this.menu3 = new JButton("menu 3");
            menu3.setBounds(20,130,80,30);
        }
        return menu3;
    }

    public void setMenu3(JButton menu3) {
        this.menu3 = menu3;
    }

    public JButton getMenu4() {
        if(menu4 == null){
            this.menu4 = new JButton("menu 4");
            menu4.setBounds(20,170,80,30);
        }
        return menu4;
    }

    public void setMenu4(JButton menu4) {
        this.menu4 = menu4;
    }

    public JButton getMenu5() {
        if(menu5 == null){
            this.menu5 = new JButton("menu 5");
            menu5.setBounds(20,210,80,30);
        }
        return menu5;
    }

    public void setMenu5(JButton menu5) {
        this.menu5 = menu5;
    }

    public JButton getMenu6() {
        if(menu6 == null){
            this.menu6 = new JButton("menu 6");
            menu6.setBounds(20,250,80,30);
        }
        return menu6;
    }

    public void setMenu6(JButton menu6) {
        this.menu6 = menu6;
    }

    public JButton getMenu7() {
        if(menu7 == null){
            this.menu7 = new JButton("menu 7");
            menu7.setBounds(20,290,80,30);
        }
        return menu7;
    }

    public void setMenu7(JButton menu7) {
        this.menu7 = menu7;
    }

    public JButton getMenu8() {
        if(menu8 == null){
            this.menu8 = new JButton("menu 8");
            menu8.setBounds(20,330,80,30);
        }
        return menu8;
    }

    public void setMenu8(JButton menu8) {
        this.menu8 = menu8;
    }

    
    
    public JTable getAdisyon() {
        if (adisyon == null) {            
            this.adisyon = new JTable();
            adisyon.setBounds(650, 100, 250, 500);
        }
        return adisyon;
    }

    public void setAdisyon(JTable adisyon) {
        this.adisyon = adisyon;
    }

    public JLabel getLb1() {
        if (lb1 == null) {
            this.lb1 = new JLabel("Menü Seçiniz:");
            lb1.setBounds(30, 10, 100, 30);
        }
        return lb1;
    }

    public void setLb1(JLabel lb1) {
        this.lb1 = lb1;
    }

    public JLabel getLb2() {
        if (lb2 == null) {
            this.lb2 = new JLabel("PIZZA HOUSE");
            lb2.setBounds(650, 50, 250, 30);
            lb2.setFont(new Font("Arial", Font.PLAIN, 30));
        }
        return lb2;
    }

    public void setLb2(JLabel lb2) {
        this.lb2 = lb2;
    }

    public JButton getB2() {
        if (b2 == null) {
            this.b2 = new JButton("Adisyona Ekle");
            b2.setBounds(30, 500, 200, 50);
            b2.addActionListener(new UserOpenPageAction(this));
        }
        return b2;
    }

    public void setB2(JButton b2) {
        this.b2 = b2;
    }

    public JButton getB3() {
        if (b3 == null) {
            this.b3 = new JButton("Masayi Kapat");
            b3.setBounds(650, 500, 200, 50);
            b3.addActionListener(new UserOpenPageAction(this));
        }
        return b3;
    }

    public void setB3(JButton b3) {
        this.b3 = b3;
    }

    

    private JPanel initPanel() {
        JPanel musteriPanel = new JPanel();
        musteriPanel.setLayout(null);

        musteriPanel.add(getLb1());
        musteriPanel.add(getLb2());
        musteriPanel.add(getB2());
        musteriPanel.add(getB2());
        musteriPanel.add(getB3());       
        musteriPanel.add(getAdisyon());
        musteriPanel.add(getMenu1());
        musteriPanel.add(getMenu2());
        musteriPanel.add(getMenu3());
        musteriPanel.add(getMenu4());
        musteriPanel.add(getMenu5());
        musteriPanel.add(getMenu6());
        musteriPanel.add(getMenu7());
        musteriPanel.add(getMenu8());
        musteriPanel.add(getAddFoodsp());
        
        

        return musteriPanel;
    }

}
