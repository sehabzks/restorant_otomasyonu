package gui;

import Action.AdminPageAction;
import Controller.AdminController;
import Entity.Admin;
import Entity.Food;
import Entity.Personel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class AdminPage extends JFrame {

    private JButton Open, Close, Add, addFood;
    private JLabel baslik;
    private JTextField perEkleText, perEkleText2, perEkleText3, foodName, foodPrice;
    private JTable GarsonEkleCikar,foodTable;
    private JScrollPane GarsonEkleCikarsp,addFoodsp;
    private DefaultTableModel personelModel,foodModel;
    private Object[] personelData = null,foodData = null;
    private JLabel perEkle;

    AdminController admin;

    public AdminPage() throws IOException {
        personelModel = new DefaultTableModel();
        admin = new AdminController();
        Object[] colPersonelName = new Object[4];
        colPersonelName[0] = "ID";
        colPersonelName[1] = "Name";
        colPersonelName[2] = "Salary";
        colPersonelName[3] = "Type";
        personelModel.setColumnIdentifiers(colPersonelName);
        personelData = new Object[4];
        List<Personel> personeller = admin.getPersonelList();
        for (int i = 0; i < personeller.size(); i++) {
            personelData[0] = personeller.get(i).getId();
            personelData[1] = personeller.get(i).getName();
            personelData[2] = personeller.get(i).getSalary();
            personelData[3] = personeller.get(i).getType();
            personelModel.addRow(personelData);
        }
        
        foodModel = new DefaultTableModel();
        
        Object[] colFoodName = new Object[3];
        colFoodName[0] = "ID";
        colFoodName[1] = "Name";
        colFoodName[2] = "Price";
        
        foodModel.setColumnIdentifiers(colFoodName);
        foodData = new Object[4];
        List<Food> foods = admin.getFoodList();
        for (int i = 0; i < foods.size(); i++) {
            foodData[0] = foods.get(i).getId();
            foodData[1] = foods.get(i).getName();
            foodData[2] = foods.get(i).getPrice();            
            foodModel.addRow(foodData);
        }
        initJFrame();
    }

    public void updatepersonelModel() {

        personelModel.setRowCount(0);
        List<Personel> personeller = admin.getPersonelList();
        for (int i = 0; i < personeller.size(); i++) {
            personelData[0] = personeller.get(i).getId();
            personelData[1] = personeller.get(i).getName();
            personelData[2] = personeller.get(i).getSalary();
            personelData[3] = personeller.get(i).getType();
            personelModel.addRow(personelData);
        }
    }
    
     public void updatefoodModel() {

        foodModel.setRowCount(0);
        List<Food> foods = admin.getFoodList();
        for (int i = 0; i < foods.size(); i++) {
            foodData[0] = foods.get(i).getId();
            foodData[1] = foods.get(i).getName();
            foodData[2] = foods.get(i).getPrice();            
            foodModel.addRow(foodData);
        }
    }

    private void initJFrame() throws IOException {
        add(initPanel());
        setTitle("Admin Kontrol Sayfası");
        setIconImage(ImageIO.read(new File("res/Icon.png")));
        setSize(1300, 800);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JPanel initPanel() {
        JPanel AdminControlPage = new JPanel();
        AdminControlPage.setLayout(null);
        AdminControlPage.add(getBaslik());
        AdminControlPage.add(getAdd());
        AdminControlPage.add(getPerEkleText());
        AdminControlPage.add(getPerEkleText2());
        AdminControlPage.add(getPerEkleText3());
        AdminControlPage.add(getClose());
        AdminControlPage.add(getPerEkle());
        AdminControlPage.add(getGarsonEkleCikarsp());
        AdminControlPage.add(getOpen());
        AdminControlPage.add(getAddFoodsp());
        AdminControlPage.add(getFoodName());
        AdminControlPage.add(getFoodPrice());
        AdminControlPage.add(getAddFood());
        

        return AdminControlPage;
    }

    public JLabel getPerEkle() {
        if (perEkle == null) {
            this.perEkle = new JLabel("Personel Ekle");
            perEkle.setBounds(320, 150, 150, 20);
        }
        return perEkle;
    }

    public void setPerEkle(JLabel perEkle) {
        this.perEkle = perEkle;
    }

    public JButton getAdd() {
        if (Add == null) {
            this.Add = new JButton("Personel Ekle");
            Add.setBounds(320, 300, 150, 30);
            Add.addActionListener(new AdminPageAction(this));
        }
        return Add;
    }

    public void setAdd(JButton Add) {
        this.Add = Add;
    }

    public JTextField getPerEkleText() {
        if (perEkleText == null) {
            this.perEkleText = new JTextField();
            perEkleText.setBounds(320, 180, 150, 30);
        }
        return perEkleText;
    }

    public void setPerEkleText(JTextField perEkleText) {
        this.perEkleText = perEkleText;
    }

    public JTextField getPerEkleText2() {
        if (perEkleText2 == null) {
            this.perEkleText2 = new JTextField();
            perEkleText2.setBounds(320, 220, 150, 30);
        }
        return perEkleText2;
    }

    public void setPerEkleText2(JTextField perEkleText2) {
        this.perEkleText2 = perEkleText2;
    }

    public JTextField getPerEkleText3() {
        if (perEkleText3 == null) {
            this.perEkleText3 = new JTextField();
            perEkleText3.setBounds(320, 260, 150, 30);
        }
        return perEkleText3;
    }

    public void setPerEkleText3(JTextField perEkleText3) {
        this.perEkleText3 = perEkleText3;
    }

    public JScrollPane getGarsonEkleCikarsp() {
        if (GarsonEkleCikarsp == null) {
            this.GarsonEkleCikarsp = new JScrollPane(getGarsonEkleCikar());
            GarsonEkleCikarsp.setBounds(10, 150, 250, 500);
            GarsonEkleCikarsp.setViewportView(getGarsonEkleCikar());
        }
        return GarsonEkleCikarsp;
    }

    public void setGarsonEkleCikarsp(JScrollPane GarsonEkleCikarsp) {
        this.GarsonEkleCikarsp = GarsonEkleCikarsp;
    }

    public JScrollPane getAddFoodsp() {
        if (addFoodsp == null) {
            this.addFoodsp = new JScrollPane(getFoodTable());
            addFoodsp.setBounds(800, 100, 250, 350);
            addFoodsp.setViewportView(getFoodTable());
        }
        return addFoodsp;
    }

    public void setAddFoodsp(JScrollPane addFoodsp) {
        this.addFoodsp = addFoodsp;
    }
    
    

    public JTable getGarsonEkleCikar() {
        if (GarsonEkleCikar == null) {
            this.GarsonEkleCikar = new JTable();
            GarsonEkleCikar.setBounds(10, 100, 250, 500);
            GarsonEkleCikar.setModel(personelModel);
        }
        return GarsonEkleCikar;
    }

    public void setGarsonEkleCikar(JTable GarsonEkleCikar) {
        this.GarsonEkleCikar = GarsonEkleCikar;
    }

    public JButton getOpen() {
        if (Open == null) {
            this.Open = new JButton("Restorantı Aç");
            Open.setBounds(800, 500, 250, 100);
            Open.addActionListener(new AdminPageAction(this));
        }
        return Open;
    }

    public void setOpen(JButton Open) {
        this.Open = Open;
    }

    public JButton getClose() {
        if (Close == null) {
            this.Close = new JButton("Restorantı Kapat");
            Close.setBounds(800, 630, 250, 100);
            Close.addActionListener(new AdminPageAction(this));
        }
        return Close;
    }

    public void setClose(JButton Close) {
        this.Close = Close;
    }

    public JLabel getBaslik() {
        if (baslik == null) {
            this.baslik = new JLabel("Admin Kontrol Sayfası");
            baslik.setBounds(450, 50, 340, 50);
            baslik.setFont(new Font("Arial", Font.PLAIN, 35));
        }
        return baslik;
    }

    public void setBaslik(JLabel baslik) {
        this.baslik = baslik;
    }

    public JButton getAddFood() {
        if(addFood == null){
            this.addFood = new JButton("Yemek Ekle");
            addFood.setBounds(1100,250,100,30);
            addFood.addActionListener(new AdminPageAction(this));
        }
        return addFood;
    }

    public void setAddFood(JButton addFood) {
        this.addFood = addFood;
    }

    public JTextField getFoodName() {
        if(foodName == null){
            this.foodName = new JTextField();
            foodName.setBounds(1100,150,120,30);
        }
        return foodName;
    }

    public void setFoodName(JTextField foodName) {
        this.foodName = foodName;
    }

    public JTextField getFoodPrice() {
        if(foodPrice == null){
            this.foodPrice = new JTextField();
            foodPrice.setBounds(1100,190,120,30);
        }
        return foodPrice;
    }

    public void setFoodPrice(JTextField foodPrice) {
        this.foodPrice = foodPrice;
    }

    public JTable getFoodTable() {
        if (foodTable == null) {
            this.foodTable = new JTable();
            foodTable.setBounds(800, 100, 250, 350);
            foodTable.setModel(foodModel);
        }
        return foodTable;
    }

    public void setFoodTable(JTable foodTable) {
        this.foodTable = foodTable;
    }

    
    
}
