
package Entity;


public class waiter extends Personel {
    private int id;
    private String name;
    private int Salary;
    private String type;
    public String MakeAnOrder(){
        System.out.println("garson siparişi aldı");
        return null;
    }

    /**
     *
     * @return
     */
    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    @Override
    public int getSalary() {
        return Salary;
    }

    @Override
    public void setSalary(int Salary) {
        this.Salary = Salary;
    }

    @Override
    public String getType() {
        return type;
    }

    /**
     *
     * @param type
     */
    @Override
    public void setType(String type) {
        this.type = type;
    }
    
}
