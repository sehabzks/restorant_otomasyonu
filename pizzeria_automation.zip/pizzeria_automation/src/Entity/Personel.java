package Entity;

public class Personel {

    private int id;
    private String name;
    private int Salary;
    private String type;
    
    
    public Personel() {
    }

    public Personel(int id, String name, int Salary, String type) {
        this.id = id;
        this.name = name;
        this.Salary = Salary;
        this.type = type;
    }

    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSalary() {
        return Salary;
    }

    public void setSalary(int Salary) {
        this.Salary = Salary;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return id + "," + name + "," + Salary + "," + type;
    }
    
    
}
