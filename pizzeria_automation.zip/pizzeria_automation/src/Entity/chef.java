
package Entity;

public class chef extends Personel {
    private int id;
    private String name;
    private int Salary;
    private String type;
    
    public String TakeAnOrder(){
        System.out.println("şef siparişi aldı");
        return null;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    @Override
    public void setId(int id) {
        this.id = id;
    }

    @Override
    public int getSalary() {
        return Salary;
    }

    @Override
    public void setSalary(int Salary) {
        this.Salary = Salary;
    }

    @Override
    public String getType() {
        return type;
    }

    /**
     *
     * @param type
     */
    @Override
    public void setType(String type) {
        this.type = type;
    }
    
}
