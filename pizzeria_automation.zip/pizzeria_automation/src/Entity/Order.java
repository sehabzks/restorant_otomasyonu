
package Entity;

public abstract class Order {
    public int OrderId;
    public int AddMenuItem(String name,int Price){
        
        return 0;
        
    }
    public int RemoveMenuItem(){
        
        return 0;
        
    }
    
}
