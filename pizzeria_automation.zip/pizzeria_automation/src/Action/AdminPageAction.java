package Action;

import Controller.AdminController;
import gui.AdminPage;
import gui.GUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import Entity.*;

public class AdminPageAction implements ActionListener {

    private AdminPage ap;
    AdminController a;
    int z=3;
    int x=11;
    
    
    public AdminPageAction(AdminPage ap) {
        this.ap = ap;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource() == ap.getOpen()) {
            JOptionPane.showMessageDialog(null, "pizzaria açıldı");
            
        } else if (e.getSource() == ap.getClose()) {
            JOptionPane.showMessageDialog(null, "pizzaria kapatıldı.");
            try {
                GUI g = new GUI();
                ap.dispose();
            } catch (IOException ex) {
                Logger.getLogger(AdminLoginAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (e.getSource() == ap.getAdd()) {
            if (ap.getPerEkleText().getText().length() == 0 || ap.getPerEkleText2().getText().length() == 0 || ap.getPerEkleText3().getText().length() == 0) {
                JOptionPane.showMessageDialog(null, "Tüm Alanları Doldurunuz");
            } else {
                
                try {
                    a = new AdminController();
                    a.PersonelEkle(z, ap.getPerEkleText().getText(), Integer.parseInt(ap.getPerEkleText2().getText()), ap.getPerEkleText3().getText());
                    z++;
                    JOptionPane.showMessageDialog(null, "Personel başarıyla eklendi");
                    ap.getPerEkleText().setText(null);
                    ap.getPerEkleText2().setText(null);
                    ap.getPerEkleText3().setText(null);
                    ap.updatepersonelModel();
                    
                } catch (IOException ex) {
                    Logger.getLogger(AdminPageAction.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        else if(e.getSource() == ap.getAddFood()){
            try {
                a = new AdminController();
                a.YemekEkle(x, ap.getFoodName().getText(), Integer.parseInt(ap.getFoodPrice().getText()));
                x++;
                JOptionPane.showMessageDialog(null,"Yemek başarıyla eklendi");
                ap.getFoodName().setText(null);
                ap.getFoodPrice().setText(null);
                ap.updatefoodModel();
            } catch (IOException ex) {
                Logger.getLogger(AdminPageAction.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
}
