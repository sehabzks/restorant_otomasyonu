package Action;

import Controller.AdminController;
import gui.AdminLogin;
import gui.AdminPage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class AdminLoginAction implements ActionListener {

    private AdminLogin a;

    public AdminLoginAction(AdminLogin a) {
        this.a = a;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == a.getLogin_button()) {
            if (a.getA_Nick().getText().length() == 0 || a.getA_pass().getText().length() == 0) {
                JOptionPane.showMessageDialog(null, "Lütfen tüm alanları doldurunuz");
            } else if (e.getSource() == a.getLogin_button()) {
                String kAdi = a.getA_Nick().getText();
                String s = a.getA_pass().getText();
                AdminController control = new AdminController();
                
                try {
                    if (!control.Kontrol(kAdi, s)) {
                        
                        JOptionPane.showMessageDialog(null, "Kullanıcı adı veya şifre yanlış");

                    } else {
                        JOptionPane.showMessageDialog(null, "Giriş Başarılı");
                        try {
                            AdminPage ap = new AdminPage();
                        } catch (IOException ex) {
                            Logger.getLogger(AdminLoginAction.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        a.dispose();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(AdminLoginAction.class.getName()).log(Level.SEVERE, null, ex);
                }
                 

            }

        }

    }

}
