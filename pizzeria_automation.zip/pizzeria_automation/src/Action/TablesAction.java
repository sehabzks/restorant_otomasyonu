
package Action;

import gui.Tables;
import gui.UserPage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TablesAction implements ActionListener{
    
    
    private Tables T;
    
    
    public TablesAction(Tables T) {
        this.T = T;
    }
    
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if( e.getSource()== T.getMasa1())
        {
            try {
                UserPage m1 = new UserPage();
                T.dispose();
            } catch (IOException ex) {
                Logger.getLogger(TablesAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if (e.getSource()== T.getMasa2())
        {
            try {
                UserPage m2 = new UserPage();
                T.dispose();
            } catch (IOException ex) {
                Logger.getLogger(TablesAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if (e.getSource()== T.getMasa3())
        {
            try {
                UserPage m3 = new UserPage();
                T.dispose();
            } catch (IOException ex) {
                Logger.getLogger(TablesAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if (e.getSource()== T.getMasa4())
        {
            try {
                UserPage m4 = new UserPage();
                T.dispose();
            } catch (IOException ex) {
                Logger.getLogger(TablesAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if (e.getSource()== T.getMasa5())
        {
            try {
                UserPage m5 = new UserPage();
                T.dispose();
            } catch (IOException ex) {
                Logger.getLogger(TablesAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if (e.getSource()== T.getMasa6())
        {
            try {
                UserPage m6 = new UserPage();
                T.dispose();
            } catch (IOException ex) {
                Logger.getLogger(TablesAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
       
    }
    
}
