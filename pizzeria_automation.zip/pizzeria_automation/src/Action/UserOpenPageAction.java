package Action;

import gui.Tables;
import gui.UserPage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserOpenPageAction implements ActionListener {

    private UserPage up;

    public UserOpenPageAction(UserPage up) {
        this.up = up;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == up.getB2()) {

        } else if (e.getSource() == up.getB3()) {
            try {
                Tables t = new Tables();
                up.dispose();
            } catch (IOException ex) {
                Logger.getLogger(UserOpenPageAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        
    }

    }
}
