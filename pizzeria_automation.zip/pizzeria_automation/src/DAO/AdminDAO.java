package DAO;

import Entity.Admin;
import Entity.Food;
import Entity.Personel;
import File.FileOp;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.ArrayList;
import java.util.List;

public class AdminDAO extends AbstractDAO<Admin> {

    ArrayList<Personel> personeller = new ArrayList<>();
    ArrayList<Food> foods = new ArrayList<>();

    @Override
    public void insert(Admin entity) throws IOException {
        FileOp f = new FileOp();
        f.yazdir(entity.toString());
    }
    
    public ArrayList<Food> getFoodList() {
        FileReader FR = null;
        try {
            FR = new FileReader("C:\\Users\\Alperen\\Documents\\NetBeansProjects\\pizzeria_automation\\src\\TXT\\food.txt");
            BufferedReader BR = new BufferedReader(FR);
            String line = BR.readLine();
            while (line != null) {
                String veri[] = line.split(",");
                Food f = new Food(Integer.parseInt(veri[0]), veri[1], Integer.parseInt(veri[2]));
                this.foods.add(f);
                line = BR.readLine();
            }
            return foods;
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                FR.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }

    public boolean Kontrol(Admin admin) throws FileNotFoundException, IOException {
        FileReader fr = new FileReader("C:\\Users\\Alperen\\Documents\\NetBeansProjects\\pizzeria_automation\\src\\TXT\\admin.txt");
        BufferedReader br = new BufferedReader(fr);
        String line = br.readLine();

        while (line != null) {
            String[] parts = line.split(",");
            String kullaniciAdi = parts[0];
            String sifre = parts[1];

            if (kullaniciAdi.equals(admin.getKullaniciAdi()) && sifre.equals(admin.getSifre())) {
                fr.close();
                br.close();
                return true;
            } else {
                fr.close();
                br.close();
                return false;
            }
        }
        fr.close();
        br.close();
        return false;

    }

    public ArrayList<Personel> getPersonelList() {
        FileReader FR = null;
        try {
            FR = new FileReader("C:\\Users\\Alperen\\Documents\\NetBeansProjects\\pizzeria_automation\\src\\TXT\\personel.txt");
            BufferedReader BR = new BufferedReader(FR);
            String line = BR.readLine();
            while (line != null) {
                String veri[] = line.split(",");
                Personel p = new Personel(Integer.parseInt(veri[0]), veri[1], Integer.parseInt(veri[2]), veri[3]);
                this.personeller.add(p);
                line = BR.readLine();
            }
            return personeller;
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                FR.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }

    public void PersonelEkle(Personel personel) throws FileNotFoundException, IOException {
        try {
            FileWriter FR = new FileWriter("C:\\Users\\Alperen\\Documents\\NetBeansProjects\\pizzeria_automation\\src\\TXT\\personel.txt", true);
            try ( BufferedWriter BR = new BufferedWriter(FR)) {
                BR.append(personel.toString() + "\n");
            }
        } catch (IOException e) {

        }
    }
    
    public void YemekEkle(Food food)throws FileNotFoundException, IOException{
        try {
            FileWriter FR = new FileWriter("C:\\Users\\Alperen\\Documents\\NetBeansProjects\\pizzeria_automation\\src\\TXT\\food.txt", true);
            try ( BufferedWriter BR = new BufferedWriter(FR)) {
                BR.append(food.toString() + "\n");
            }
        } catch (IOException e) {

        }
    }
}
